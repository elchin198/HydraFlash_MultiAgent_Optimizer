# Timing utilities
