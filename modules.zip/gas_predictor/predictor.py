# Gas prediction logic
