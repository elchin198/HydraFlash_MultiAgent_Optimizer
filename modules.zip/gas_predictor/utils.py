# Utility functions for gas prediction
