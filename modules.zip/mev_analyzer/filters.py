# Filters and validators for MEV
