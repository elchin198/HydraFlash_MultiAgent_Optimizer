# Profit routing and execution logic
