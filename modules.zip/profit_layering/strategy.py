# Profit strategies definitions
